-- Create database
CREATE DATABASE IF NOT EXISTS farmer_management;
USE farmer_management;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE,
    user_type ENUM('farmer', 'buyer', 'admin') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Admin profiles table
CREATE TABLE IF NOT EXISTS admin_profiles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    address TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Farmer profiles table
CREATE TABLE IF NOT EXISTS farmer_profiles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    address TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Buyer profiles table
CREATE TABLE IF NOT EXISTS buyer_profiles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    address TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    farmer_id INT,
    product_name VARCHAR(100) NOT NULL,
    description TEXT,
    quantity INT NOT NULL,
    minimum_price DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (farmer_id) REFERENCES users(id)
);

-- Contact history table
CREATE TABLE IF NOT EXISTS contact_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    contact_id INT,
    contact_type ENUM('farmer', 'buyer') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Purchase requests table
CREATE TABLE IF NOT EXISTS purchase_requests (
    id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT,
    buyer_id INT,
    quantity INT NOT NULL,
    offered_price DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id),
    FOREIGN KEY (buyer_id) REFERENCES users(id)
); 