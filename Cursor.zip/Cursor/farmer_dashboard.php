<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in and is a farmer
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'farmer') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle product submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_product'])) {
    $product_name = $_POST['product_name'];
    $description = $_POST['description'];
    $quantity = $_POST['quantity'];
    $minimum_price = $_POST['minimum_price'];

    try {
        $stmt = $pdo->prepare("INSERT INTO products (farmer_id, product_name, description, quantity, minimum_price) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$user_id, $product_name, $description, $quantity, $minimum_price]);
        $success = "Product added successfully!";
    } catch (Exception $e) {
        $error = "Failed to add product: " . $e->getMessage();
    }
}

// Handle purchase request response
if (isset($_POST['request_response'])) {
    $request_id = $_POST['request_id'];
    $status = $_POST['status'];
    
    try {
        $stmt = $pdo->prepare("UPDATE purchase_requests SET status = ? WHERE id = ? AND product_id IN (SELECT id FROM products WHERE farmer_id = ?)");
        $stmt->execute([$status, $request_id, $user_id]);
        $success = "Request updated successfully!";
    } catch (Exception $e) {
        $error = "Failed to update request: " . $e->getMessage();
    }
}

// Fetch farmer's products
$stmt = $pdo->prepare("SELECT * FROM products WHERE farmer_id = ? ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$products = $stmt->fetchAll();

// Fetch purchase requests for farmer's products
$stmt = $pdo->prepare("
    SELECT pr.*, p.product_name, u.username as buyer_name 
    FROM purchase_requests pr 
    JOIN products p ON pr.product_id = p.id 
    JOIN users u ON pr.buyer_id = u.id 
    WHERE p.farmer_id = ? 
    ORDER BY pr.created_at DESC
");
$stmt->execute([$user_id]);
$requests = $stmt->fetchAll();

// Fetch contact history
$stmt = $pdo->prepare("
    SELECT ch.*, u.username, u.user_type 
    FROM contact_history ch 
    JOIN users u ON ch.contact_id = u.id 
    WHERE ch.user_id = ? 
    ORDER BY ch.created_at DESC
");
$stmt->execute([$user_id]);
$contacts = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farmer Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1 class="system-title">Farmer Buyer Contact Management System</h1>
        <div class="dashboard">
            <div class="dashboard-header">
                <h2 class="dashboard-title">Farmer Dashboard</h2>
                <a href="logout.php" class="logout-btn">Logout</a>
            </div>

            <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

            <div class="dashboard-grid">
                <!-- Action Buttons -->
                <div class="dashboard-card">
                    <h3>Quick Actions</h3>
                    <div class="button-group">
                        <a href="add_product.php" class="btn">Add New Product</a>
                        <a href="your_products.php" class="btn">Your Products</a>
                        <a href="purchase_requests.php" class="btn">Purchase Requests</a>
                        <a href="save_contact.php" class="btn">Save Buyer Contact</a>
                        <a href="contact_history.php" class="btn">Contact History</a>
                    </div>
                </div>

                <!-- Your Products Summary -->
                <div class="dashboard-card">
                    <h3>Your Products Summary</h3>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (array_slice($products, 0, 5) as $product): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                                    <td><?php echo htmlspecialchars($product['quantity']); ?></td>
                                    <td>$<?php echo htmlspecialchars($product['minimum_price']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php if (count($products) > 5): ?>
                        <p><a href="your_products.php" class="btn">View All Products</a></p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Recent Purchase Requests -->
                <div class="dashboard-card">
                    <h3>Recent Purchase Requests</h3>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Buyer</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (array_slice($requests, 0, 5) as $request): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($request['product_name']); ?></td>
                                    <td><?php echo htmlspecialchars($request['buyer_name']); ?></td>
                                    <td><?php echo htmlspecialchars($request['status']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php if (count($requests) > 5): ?>
                        <p><a href="purchase_requests.php" class="btn">View All Requests</a></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 