<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_type = $_SESSION['user_type'];

// Fetch contact history with phone numbers
$stmt = $pdo->prepare("
    SELECT ch.*, 
           u.username,
           u.user_type,
           COALESCE(fp.phone, bp.phone) as phone,
           COALESCE(fp.full_name, bp.full_name) as full_name
    FROM contact_history ch 
    JOIN users u ON ch.contact_id = u.id 
    LEFT JOIN farmer_profiles fp ON u.id = fp.user_id
    LEFT JOIN buyer_profiles bp ON u.id = bp.user_id
    WHERE ch.user_id = ? 
    ORDER BY ch.created_at DESC
");
$stmt->execute([$user_id]);
$contacts = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact History</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1 class="system-title">Farmer Buyer Contact Management System</h1>
        <div class="dashboard">
            <div class="dashboard-header">
                <h2 class="dashboard-title">Contact History</h2>
                <?php if ($user_type == 'farmer'): ?>
                <a href="farmer_dashboard.php" class="btn">Back to Dashboard</a>
                <?php else: ?>
                <a href="buyer_dashboard.php" class="btn">Back to Dashboard</a>
                <?php endif; ?>
            </div>

            <div class="dashboard-card">
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Type</th>
                                <th>Phone</th>
                                <th>Date Added</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($contacts as $contact): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($contact['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($contact['username']); ?></td>
                                <td><?php echo htmlspecialchars($contact['user_type']); ?></td>
                                <td><?php echo htmlspecialchars($contact['phone']); ?></td>
                                <td><?php echo date('Y-m-d H:i', strtotime($contact['created_at'])); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 