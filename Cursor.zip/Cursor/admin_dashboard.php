<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle user deletion
if (isset($_POST['delete_user'])) {
    $delete_id = $_POST['delete_id'];
    try {
        $pdo->beginTransaction();
        
        // Delete from respective profile table
        $stmt = $pdo->prepare("DELETE FROM farmer_profiles WHERE user_id = ?");
        $stmt->execute([$delete_id]);
        $stmt = $pdo->prepare("DELETE FROM buyer_profiles WHERE user_id = ?");
        $stmt->execute([$delete_id]);
        
        // Delete from users table
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$delete_id]);
        
        $pdo->commit();
        $success = "User deleted successfully!";
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Failed to delete user: " . $e->getMessage();
    }
}

// Handle product deletion
if (isset($_POST['delete_product'])) {
    $product_id = $_POST['product_id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $success = "Product deleted successfully!";
    } catch (Exception $e) {
        $error = "Failed to delete product: " . $e->getMessage();
    }
}

// Fetch all users
$stmt = $pdo->prepare("
    SELECT u.*, 
           COALESCE(fp.full_name, bp.full_name, ap.full_name) as full_name,
           COALESCE(fp.phone, bp.phone, ap.phone) as phone,
           COALESCE(fp.address, bp.address, ap.address) as address
    FROM users u
    LEFT JOIN farmer_profiles fp ON u.id = fp.user_id
    LEFT JOIN buyer_profiles bp ON u.id = bp.user_id
    LEFT JOIN admin_profiles ap ON u.id = ap.user_id
    WHERE u.id != ?
    ORDER BY u.created_at DESC
");
$stmt->execute([$user_id]);
$users = $stmt->fetchAll();

// Fetch all products
$stmt = $pdo->prepare("
    SELECT p.*, u.username as farmer_name 
    FROM products p 
    JOIN users u ON p.farmer_id = u.id 
    ORDER BY p.created_at DESC
");
$stmt->execute();
$products = $stmt->fetchAll();

// Fetch all purchase requests
$stmt = $pdo->prepare("
    SELECT pr.*, p.product_name, 
           u1.username as buyer_name,
           u2.username as farmer_name
    FROM purchase_requests pr 
    JOIN products p ON pr.product_id = p.id 
    JOIN users u1 ON pr.buyer_id = u1.id
    JOIN users u2 ON p.farmer_id = u2.id
    ORDER BY pr.created_at DESC
");
$stmt->execute();
$requests = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="dashboard">
            <div class="dashboard-header">
                <h2 class="dashboard-title">Admin Dashboard</h2>
                <a href="logout.php" class="logout-btn">Logout</a>
            </div>

            <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

            <!-- Users Management -->
            <div class="dashboard-card">
                <h3>Users Management</h3>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Type</th>
                                <th>Full Name</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo htmlspecialchars($user['user_type']); ?></td>
                                <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($user['phone']); ?></td>
                                <td><?php echo htmlspecialchars($user['address']); ?></td>
                                <td>
                                    <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="action-btn view-btn">Edit</a>
                                    <form method="POST" action="" style="display: inline;">
                                        <input type="hidden" name="delete_id" value="<?php echo $user['id']; ?>">
                                        <button type="submit" name="delete_user" class="action-btn reject-btn" onclick="return confirm('Are you sure you want to delete this user?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Products Management -->
            <div class="dashboard-card">
                <h3>Products Management</h3>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Farmer</th>
                                <th>Description</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $product): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                                <td><?php echo htmlspecialchars($product['farmer_name']); ?></td>
                                <td><?php echo htmlspecialchars($product['description']); ?></td>
                                <td><?php echo htmlspecialchars($product['quantity']); ?></td>
                                <td>$<?php echo htmlspecialchars($product['minimum_price']); ?></td>
                                <td>
                                    <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="action-btn view-btn">Edit</a>
                                    <form method="POST" action="" style="display: inline;">
                                        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                        <button type="submit" name="delete_product" class="action-btn reject-btn" onclick="return confirm('Are you sure you want to delete this product?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Purchase Requests -->
            <div class="dashboard-card">
                <h3>Purchase Requests</h3>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Buyer</th>
                                <th>Farmer</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($requests as $request): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($request['product_name']); ?></td>
                                <td><?php echo htmlspecialchars($request['buyer_name']); ?></td>
                                <td><?php echo htmlspecialchars($request['farmer_name']); ?></td>
                                <td><?php echo htmlspecialchars($request['quantity']); ?></td>
                                <td>$<?php echo htmlspecialchars($request['offered_price']); ?></td>
                                <td><?php echo htmlspecialchars($request['status']); ?></td>
                                <td>
                                    <a href="edit_request.php?id=<?php echo $request['id']; ?>" class="action-btn view-btn">Edit</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 