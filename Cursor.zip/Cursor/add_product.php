<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in and is a farmer
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'farmer') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle product submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_name = $_POST['product_name'];
    $description = $_POST['description'];
    $quantity = $_POST['quantity'];
    $minimum_price = $_POST['minimum_price'];

    try {
        $stmt = $pdo->prepare("INSERT INTO products (farmer_id, product_name, description, quantity, minimum_price) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$user_id, $product_name, $description, $quantity, $minimum_price]);
        $success = "Product added successfully!";
    } catch (Exception $e) {
        $error = "Failed to add product: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Product</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1 class="system-title">Farmer Buyer Contact Management System</h1>
        <div class="dashboard">
            <div class="dashboard-header">
                <h2 class="dashboard-title">Add New Product</h2>
                <a href="farmer_dashboard.php" class="btn">Back to Dashboard</a>
            </div>

            <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

            <div class="dashboard-card">
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="product_name">Product Name:</label>
                        <input type="text" id="product_name" name="product_name" required>
                    </div>

                    <div class="form-group">
                        <label for="description">Description:</label>
                        <textarea id="description" name="description" required></textarea>
                    </div>

                    <div class="form-group">
                        <label for="quantity">Quantity:(kg)</label>
                        <input type="number" id="quantity" name="quantity" required min="1">
                    </div>

                    <div class="form-group">
                        <label for="minimum_price">Minimum Price ($):</label>
                        <input type="number" id="minimum_price" name="minimum_price" step="0.01" required min="0">
                    </div>

                    <button type="submit" class="btn">Add Product</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html> 