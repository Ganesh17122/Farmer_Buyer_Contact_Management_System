<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$request_id = $_GET['id'] ?? null;
if (!$request_id) {
    header("Location: admin_dashboard.php");
    exit();
}

// Fetch request details with related information
$stmt = $pdo->prepare("
    SELECT pr.*, 
           p.product_name, p.minimum_price,
           u1.username as buyer_name,
           u2.username as farmer_name
    FROM purchase_requests pr
    JOIN products p ON pr.product_id = p.id
    JOIN users u1 ON pr.buyer_id = u1.id
    JOIN users u2 ON p.farmer_id = u2.id
    WHERE pr.id = ?
");
$stmt->execute([$request_id]);
$request = $stmt->fetch();

if (!$request) {
    header("Location: admin_dashboard.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $quantity = $_POST['quantity'];
    $offered_price = $_POST['offered_price'];
    $status = $_POST['status'];

    try {
        $stmt = $pdo->prepare("UPDATE purchase_requests SET quantity = ?, offered_price = ?, status = ? WHERE id = ?");
        $stmt->execute([$quantity, $offered_price, $status, $request_id]);
        
        $success = "Purchase request updated successfully!";
        
        // Refresh request data
        $stmt = $pdo->prepare("
            SELECT pr.*, 
                   p.product_name, p.minimum_price,
                   u1.username as buyer_name,
                   u2.username as farmer_name
            FROM purchase_requests pr
            JOIN products p ON pr.product_id = p.id
            JOIN users u1 ON pr.buyer_id = u1.id
            JOIN users u2 ON p.farmer_id = u2.id
            WHERE pr.id = ?
        ");
        $stmt->execute([$request_id]);
        $request = $stmt->fetch();
    } catch (Exception $e) {
        $error = "Failed to update purchase request: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Purchase Request - Admin Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="dashboard">
            <div class="dashboard-header">
                <h2 class="dashboard-title">Edit Purchase Request</h2>
                <a href="admin_dashboard.php" class="btn">Back to Dashboard</a>
            </div>

            <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

            <div class="dashboard-card">
                <div class="info-section">
                    <h3>Request Details</h3>
                    <p><strong>Product:</strong> <?php echo htmlspecialchars($request['product_name']); ?></p>
                    <p><strong>Buyer:</strong> <?php echo htmlspecialchars($request['buyer_name']); ?></p>
                    <p><strong>Farmer:</strong> <?php echo htmlspecialchars($request['farmer_name']); ?></p>
                    <p><strong>Minimum Price:</strong> $<?php echo htmlspecialchars($request['minimum_price']); ?></p>
                </div>

                <form method="POST" action="">
                    <div class="form-group">
                        <label for="quantity">Quantity:</label>
                        <input type="number" id="quantity" name="quantity" value="<?php echo htmlspecialchars($request['quantity']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="offered_price">Offered Price:</label>
                        <input type="number" step="0.01" id="offered_price" name="offered_price" value="<?php echo htmlspecialchars($request['offered_price']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="status">Status:</label>
                        <select id="status" name="status" required>
                            <option value="pending" <?php echo $request['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="accepted" <?php echo $request['status'] == 'accepted' ? 'selected' : ''; ?>>Accepted</option>
                            <option value="rejected" <?php echo $request['status'] == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                        </select>
                    </div>

                    <button type="submit" class="btn">Update Request</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html> 