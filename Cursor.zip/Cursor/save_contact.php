<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_type = $_SESSION['user_type'];

// Handle contact saving
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_contact'])) {
    $contact_id = $_POST['contact_id'];
    
    try {
        // Check if contact already exists
        $stmt = $pdo->prepare("SELECT * FROM contact_history WHERE user_id = ? AND contact_id = ?");
        $stmt->execute([$user_id, $contact_id]);
        
        if (!$stmt->fetch()) {
            $stmt = $pdo->prepare("INSERT INTO contact_history (user_id, contact_id) VALUES (?, ?)");
            $stmt->execute([$user_id, $contact_id]);
            $success = "Contact saved successfully!";
        } else {
            $error = "Contact already saved!";
        }
    } catch (Exception $e) {
        $error = "Failed to save contact: " . $e->getMessage();
    }
}

// Fetch available contacts based on user type
if ($user_type == 'farmer') {
    $stmt = $pdo->prepare("
        SELECT u.id, u.username, u.user_type, bp.full_name, bp.phone
        FROM users u
        JOIN buyer_profiles bp ON u.id = bp.user_id
        WHERE u.id != ? AND u.id NOT IN (SELECT contact_id FROM contact_history WHERE user_id = ?)
        ORDER BY bp.full_name
    ");
} else {
    $stmt = $pdo->prepare("
        SELECT u.id, u.username, u.user_type, fp.full_name, fp.phone
        FROM users u
        JOIN farmer_profiles fp ON u.id = fp.user_id
        WHERE u.id != ? AND u.id NOT IN (SELECT contact_id FROM contact_history WHERE user_id = ?)
        ORDER BY fp.full_name
    ");
}
$stmt->execute([$user_id, $user_id]);
$available_contacts = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Save Contact</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1 class="system-title">Farmer Buyer Contact Management System</h1>
        <div class="dashboard">
            <div class="dashboard-header">
                <h2 class="dashboard-title">Save Contact</h2>
                <?php if ($user_type == 'farmer'): ?>
                <a href="farmer_dashboard.php" class="btn">Back to Dashboard</a>
                <?php else: ?>
                <a href="buyer_dashboard.php" class="btn">Back to Dashboard</a>
                <?php endif; ?>
            </div>

            <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

            <div class="dashboard-card">
                <h3>Available Contacts</h3>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Type</th>
                                <th>Phone</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($available_contacts as $contact): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($contact['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($contact['username']); ?></td>
                                <td><?php echo htmlspecialchars($contact['user_type']); ?></td>
                                <td><?php echo htmlspecialchars($contact['phone']); ?></td>
                                <td>
                                    <form method="POST" action="" style="display: inline;">
                                        <input type="hidden" name="contact_id" value="<?php echo $contact['id']; ?>">
                                        <button type="submit" name="save_contact" class="btn">Save Contact</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 