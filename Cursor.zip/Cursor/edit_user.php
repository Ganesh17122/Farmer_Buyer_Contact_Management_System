<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$user_id = $_GET['id'] ?? null;
if (!$user_id) {
    header("Location: admin_dashboard.php");
    exit();
}

// Fetch user details
$stmt = $pdo->prepare("
    SELECT u.*, 
           COALESCE(fp.full_name, bp.full_name, ap.full_name) as full_name,
           COALESCE(fp.phone, bp.phone, ap.phone) as phone,
           COALESCE(fp.address, bp.address, ap.address) as address
    FROM users u
    LEFT JOIN farmer_profiles fp ON u.id = fp.user_id
    LEFT JOIN buyer_profiles bp ON u.id = bp.user_id
    LEFT JOIN admin_profiles ap ON u.id = ap.user_id
    WHERE u.id = ?
");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    header("Location: admin_dashboard.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $user_type = $_POST['user_type'];
    $full_name = $_POST['full_name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $new_password = $_POST['new_password'];

    try {
        $pdo->beginTransaction();

        // Update users table
        if (!empty($new_password)) {
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, user_type = ?, password = ? WHERE id = ?");
            $stmt->execute([$username, $email, $user_type, password_hash($new_password, PASSWORD_DEFAULT), $user_id]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, user_type = ? WHERE id = ?");
            $stmt->execute([$username, $email, $user_type, $user_id]);
        }

        // Update profile table based on user type
        if ($user_type == 'farmer') {
            $stmt = $pdo->prepare("DELETE FROM buyer_profiles WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $stmt = $pdo->prepare("DELETE FROM admin_profiles WHERE user_id = ?");
            $stmt->execute([$user_id]);
            
            $stmt = $pdo->prepare("INSERT INTO farmer_profiles (user_id, full_name, phone, address) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE full_name = ?, phone = ?, address = ?");
            $stmt->execute([$user_id, $full_name, $phone, $address, $full_name, $phone, $address]);
        } elseif ($user_type == 'buyer') {
            $stmt = $pdo->prepare("DELETE FROM farmer_profiles WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $stmt = $pdo->prepare("DELETE FROM admin_profiles WHERE user_id = ?");
            $stmt->execute([$user_id]);
            
            $stmt = $pdo->prepare("INSERT INTO buyer_profiles (user_id, full_name, phone, address) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE full_name = ?, phone = ?, address = ?");
            $stmt->execute([$user_id, $full_name, $phone, $address, $full_name, $phone, $address]);
        } else {
            $stmt = $pdo->prepare("DELETE FROM farmer_profiles WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $stmt = $pdo->prepare("DELETE FROM buyer_profiles WHERE user_id = ?");
            $stmt->execute([$user_id]);
            
            $stmt = $pdo->prepare("INSERT INTO admin_profiles (user_id, full_name, phone, address) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE full_name = ?, phone = ?, address = ?");
            $stmt->execute([$user_id, $full_name, $phone, $address, $full_name, $phone, $address]);
        }

        $pdo->commit();
        $success = "User updated successfully!";
        
        // Refresh user data
        $stmt = $pdo->prepare("
            SELECT u.*, 
                   COALESCE(fp.full_name, bp.full_name, ap.full_name) as full_name,
                   COALESCE(fp.phone, bp.phone, ap.phone) as phone,
                   COALESCE(fp.address, bp.address, ap.address) as address
            FROM users u
            LEFT JOIN farmer_profiles fp ON u.id = fp.user_id
            LEFT JOIN buyer_profiles bp ON u.id = bp.user_id
            LEFT JOIN admin_profiles ap ON u.id = ap.user_id
            WHERE u.id = ?
        ");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Failed to update user: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User - Admin Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="dashboard">
            <div class="dashboard-header">
                <h2 class="dashboard-title">Edit User</h2>
                <a href="admin_dashboard.php" class="btn">Back to Dashboard</a>
            </div>

            <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

            <div class="dashboard-card">
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="username">Username:</label>
                        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="user_type">User Type:</label>
                        <select id="user_type" name="user_type" required>
                            <option value="farmer" <?php echo $user['user_type'] == 'farmer' ? 'selected' : ''; ?>>Farmer</option>
                            <option value="buyer" <?php echo $user['user_type'] == 'buyer' ? 'selected' : ''; ?>>Buyer</option>
                            <option value="admin" <?php echo $user['user_type'] == 'admin' ? 'selected' : ''; ?>>Admin</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="new_password">New Password (leave blank to keep current):</label>
                        <input type="password" id="new_password" name="new_password">
                    </div>

                    <div class="form-group">
                        <label for="full_name">Full Name:</label>
                        <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone:</label>
                        <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="address">Address:</label>
                        <textarea id="address" name="address" required><?php echo htmlspecialchars($user['address']); ?></textarea>
                    </div>

                    <button type="submit" class="btn">Update User</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html> 