<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$product_id = $_GET['id'] ?? null;
if (!$product_id) {
    header("Location: admin_dashboard.php");
    exit();
}

// Fetch product details
$stmt = $pdo->prepare("
    SELECT p.*, u.username as farmer_name 
    FROM products p 
    JOIN users u ON p.farmer_id = u.id 
    WHERE p.id = ?
");
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) {
    header("Location: admin_dashboard.php");
    exit();
}

// Fetch all farmers for the dropdown
$stmt = $pdo->prepare("
    SELECT u.id, u.username, fp.full_name 
    FROM users u 
    JOIN farmer_profiles fp ON u.id = fp.user_id 
    WHERE u.user_type = 'farmer'
");
$stmt->execute();
$farmers = $stmt->fetchAll();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_name = $_POST['product_name'];
    $description = $_POST['description'];
    $quantity = $_POST['quantity'];
    $minimum_price = $_POST['minimum_price'];
    $farmer_id = $_POST['farmer_id'];

    try {
        $stmt = $pdo->prepare("UPDATE products SET product_name = ?, description = ?, quantity = ?, minimum_price = ?, farmer_id = ? WHERE id = ?");
        $stmt->execute([$product_name, $description, $quantity, $minimum_price, $farmer_id, $product_id]);
        
        $success = "Product updated successfully!";
        
        // Refresh product data
        $stmt = $pdo->prepare("
            SELECT p.*, u.username as farmer_name 
            FROM products p 
            JOIN users u ON p.farmer_id = u.id 
            WHERE p.id = ?
        ");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch();
    } catch (Exception $e) {
        $error = "Failed to update product: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - Admin Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="dashboard">
            <div class="dashboard-header">
                <h2 class="dashboard-title">Edit Product</h2>
                <a href="admin_dashboard.php" class="btn">Back to Dashboard</a>
            </div>

            <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

            <div class="dashboard-card">
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="product_name">Product Name:</label>
                        <input type="text" id="product_name" name="product_name" value="<?php echo htmlspecialchars($product['product_name']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="description">Description:</label>
                        <textarea id="description" name="description" required><?php echo htmlspecialchars($product['description']); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="quantity">Quantity:</label>
                        <input type="number" id="quantity" name="quantity" value="<?php echo htmlspecialchars($product['quantity']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="minimum_price">Minimum Price:</label>
                        <input type="number" step="0.01" id="minimum_price" name="minimum_price" value="<?php echo htmlspecialchars($product['minimum_price']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="farmer_id">Farmer:</label>
                        <select id="farmer_id" name="farmer_id" required>
                            <?php foreach ($farmers as $farmer): ?>
                            <option value="<?php echo $farmer['id']; ?>" <?php echo $farmer['id'] == $product['farmer_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($farmer['username'] . ' (' . $farmer['full_name'] . ')'); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <button type="submit" class="btn">Update Product</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html> 