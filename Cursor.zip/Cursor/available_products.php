<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in and is a buyer
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle purchase request submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['place_request'])) {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];
    $offered_price = $_POST['offered_price'];

    try {
        $stmt = $pdo->prepare("INSERT INTO purchase_requests (product_id, buyer_id, quantity, offered_price) VALUES (?, ?, ?, ?)");
        $stmt->execute([$product_id, $user_id, $quantity, $offered_price]);
        
        // Add to contact history
        $stmt = $pdo->prepare("
            INSERT INTO contact_history (user_id, contact_id)
            SELECT ?, farmer_id
            FROM products
            WHERE id = ?
        ");
        $stmt->execute([$user_id, $product_id]);
        
        $success = "Purchase request placed successfully!";
    } catch (Exception $e) {
        $error = "Failed to place request: " . $e->getMessage();
    }
}

// Fetch all available products
$stmt = $pdo->prepare("
    SELECT p.*, u.username as farmer_name, fp.phone as farmer_phone
    FROM products p 
    JOIN users u ON p.farmer_id = u.id 
    JOIN farmer_profiles fp ON u.id = fp.user_id
    ORDER BY p.created_at DESC
");
$stmt->execute();
$products = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Products</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1 class="system-title">Farmer Buyer Contact Management System</h1>
        <div class="dashboard">
            <div class="dashboard-header">
                <h2 class="dashboard-title">Available Products</h2>
                <a href="buyer_dashboard.php" class="btn">Back to Dashboard</a>
            </div>

            <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

            <div class="dashboard-card">
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Farmer</th>
                                <th>Phone</th>
                                <th>Description</th>
                                <th>Quantity</th>
                                <th>Minimum Price</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $product): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                                <td><?php echo htmlspecialchars($product['farmer_name']); ?></td>
                                <td><?php echo htmlspecialchars($product['farmer_phone']); ?></td>
                                <td><?php echo htmlspecialchars($product['description']); ?></td>
                                <td><?php echo htmlspecialchars($product['quantity']); ?></td>
                                <td>$<?php echo htmlspecialchars($product['minimum_price']); ?></td>
                                <td>
                                    <button onclick="showRequestForm(<?php echo $product['id']; ?>)" class="action-btn view-btn">Request Purchase</button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Purchase Request Modal -->
    <div id="requestModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h3>Request Purchase</h3>
            <form method="POST" action="">
                <input type="hidden" id="product_id" name="product_id">
                <div class="form-group">
                    <label for="quantity">Quantity:</label>
                    <input type="number" id="quantity" name="quantity" required>
                </div>
                <div class="form-group">
                    <label for="offered_price">Offered Price:</label>
                    <input type="number" step="0.01" id="offered_price" name="offered_price" required>
                </div>
                <button type="submit" name="place_request" class="btn">Submit Request</button>
            </form>
        </div>
    </div>

    <script>
        // Modal functionality
        const modal = document.getElementById('requestModal');
        const span = document.getElementsByClassName('close')[0];

        function showRequestForm(productId) {
            document.getElementById('product_id').value = productId;
            modal.style.display = "block";
        }

        span.onclick = function() {
            modal.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
</body>
</html> 