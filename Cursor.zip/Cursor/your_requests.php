<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in and is a buyer
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch buyer's purchase requests
$stmt = $pdo->prepare("
    SELECT pr.*, p.product_name, u.username as farmer_name, fp.phone as farmer_phone
    FROM purchase_requests pr 
    JOIN products p ON pr.product_id = p.id 
    JOIN users u ON p.farmer_id = u.id 
    JOIN farmer_profiles fp ON u.id = fp.user_id
    WHERE pr.buyer_id = ? 
    ORDER BY pr.created_at DESC
");
$stmt->execute([$user_id]);
$requests = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Purchase Requests</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1 class="system-title">Farmer Buyer Contact Management System</h1>
        <div class="dashboard">
            <div class="dashboard-header">
                <h2 class="dashboard-title">Your Purchase Requests</h2>
                <a href="buyer_dashboard.php" class="btn">Back to Dashboard</a>
            </div>

            <div class="dashboard-card">
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Farmer</th>
                                <th>Phone</th>
                                <th>Quantity</th>
                                <th>Offered Price</th>
                                <th>Status</th>
                                <th>Created At</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($requests as $request): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($request['product_name']); ?></td>
                                <td><?php echo htmlspecialchars($request['farmer_name']); ?></td>
                                <td><?php echo htmlspecialchars($request['farmer_phone']); ?></td>
                                <td><?php echo htmlspecialchars($request['quantity']); ?></td>
                                <td>$<?php echo htmlspecialchars($request['offered_price']); ?></td>
                                <td><?php echo htmlspecialchars($request['status']); ?></td>
                                <td><?php echo date('Y-m-d H:i', strtotime($request['created_at'])); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 