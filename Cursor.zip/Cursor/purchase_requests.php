<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in and is a farmer
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'farmer') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle purchase request response
if (isset($_POST['request_response'])) {
    $request_id = $_POST['request_id'];
    $status = $_POST['status'];
    
    try {
        $stmt = $pdo->prepare("UPDATE purchase_requests SET status = ? WHERE id = ? AND product_id IN (SELECT id FROM products WHERE farmer_id = ?)");
        $stmt->execute([$status, $request_id, $user_id]);
        $success = "Request updated successfully!";
    } catch (Exception $e) {
        $error = "Failed to update request: " . $e->getMessage();
    }
}

// Fetch purchase requests for farmer's products
$stmt = $pdo->prepare("
    SELECT pr.*, p.product_name, u.username as buyer_name, bp.phone as buyer_phone
    FROM purchase_requests pr 
    JOIN products p ON pr.product_id = p.id 
    JOIN users u ON pr.buyer_id = u.id 
    JOIN buyer_profiles bp ON u.id = bp.user_id
    WHERE p.farmer_id = ? 
    ORDER BY pr.created_at DESC
");
$stmt->execute([$user_id]);
$requests = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Requests</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1 class="system-title">Farmer Buyer Contact Management System</h1>
        <div class="dashboard">
            <div class="dashboard-header">
                <h2 class="dashboard-title">Purchase Requests</h2>
                <a href="farmer_dashboard.php" class="btn">Back to Dashboard</a>
            </div>

            <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

            <div class="dashboard-card">
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Buyer</th>
                                <th>Phone</th>
                                <th>Quantity</th>
                                <th>Offered Price</th>
                                <th>Status</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($requests as $request): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($request['product_name']); ?></td>
                                <td><?php echo htmlspecialchars($request['buyer_name']); ?></td>
                                <td><?php echo htmlspecialchars($request['buyer_phone']); ?></td>
                                <td><?php echo htmlspecialchars($request['quantity']); ?></td>
                                <td>$<?php echo htmlspecialchars($request['offered_price']); ?></td>
                                <td><?php echo htmlspecialchars($request['status']); ?></td>
                                <td><?php echo date('Y-m-d H:i', strtotime($request['created_at'])); ?></td>
                                <td>
                                    <?php if ($request['status'] == 'pending'): ?>
                                    <form method="POST" action="" style="display: inline;">
                                        <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                        <input type="hidden" name="status" value="accepted">
                                        <button type="submit" name="request_response" class="action-btn view-btn">Accept</button>
                                    </form>
                                    <form method="POST" action="" style="display: inline;">
                                        <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                        <input type="hidden" name="status" value="rejected">
                                        <button type="submit" name="request_response" class="action-btn reject-btn">Reject</button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 